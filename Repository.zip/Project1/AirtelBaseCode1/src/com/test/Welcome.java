package  com.test;

import org.rk.test.SampleTest;

public class Welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println ("Welcome to My Soucre Code for Devops");

	}

	public void method()
	{
		new SampleTest(); 
	}
}
