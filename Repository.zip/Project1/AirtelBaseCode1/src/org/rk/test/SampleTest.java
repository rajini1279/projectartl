package org.rk.test;

public class SampleTest {

	public SampleTest() {
		System.out.print("Sample Test");
	}

}
