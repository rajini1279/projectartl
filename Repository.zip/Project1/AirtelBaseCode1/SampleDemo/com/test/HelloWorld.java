package com.test;


public class HelloWorld {

	public static void main(String[] args) {

		System.out.println("Welomc to Sample Clinet server application");
 //jar -cvfm SampleApps.jar manifest.txt com/test/*.class
	}
}