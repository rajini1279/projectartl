﻿using Result.Models;

namespace Result.Data
{
    public interface IResultData
    {
        ResultsModel GetResults();
    }
}
